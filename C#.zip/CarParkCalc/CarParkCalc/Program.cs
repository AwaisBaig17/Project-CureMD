﻿using System;
namespace CarParkCalc 
{
    public class Bike 
    {
        private static double baseFee = 2;
        public static double parkingFee(double time) 
        {
            if (time == 24)
            {
                return 10;
            }
            else if (time < 3)
            {
                return Bike.baseFee;
            }
            else if (time > 3 && time < 24) 
            {
                double cpm = (0.5*10/60)/10;
                time = time - 3;
                return Bike.baseFee + time* 60 *cpm;
            }
            return 0;
        }
    }
    class Car 
    {
        private static double baseFee = 4;
        public static double parkingFee(double time)
        {
            if (time == 24)
            {
                return 20;
            }
            else if (time < 3)
            {
                return Car.baseFee;
            }
            else if (time > 3 && time < 24)
            {
                double cpm = (10/60);
                //Console.WriteLine(cpm);
                time = time - 3;
                return Car.baseFee + time * 6 * cpm;
            }
            return 0;
        }
    }
    class Bus
    {
        private static double baseFee = 6;
        public static double parkingFee(double time)
        {
            if (time == 24)
            {
                return 30;
            }
            else if (time < 3)
            {
                return Bus.baseFee;
            }
            else if (time > 3 && time < 24)
            {
                double cpm = (1.5 * 10 / 60)/ 10;
                time = time - 3;
                return Bus.baseFee + time* 60  * cpm;
            }
            return 0;
        }
    }
    public class CarParkCalc 
    {
        public static void Main(string[] args) 
        {
            double[] testCase = { 5, 1, 24 };
            foreach (double tcase in testCase) 
            {
                Console.WriteLine($"Time is {tcase}hrs:");
                Console.WriteLine($"For Bike: {Bike.parkingFee(tcase)}");
                Console.WriteLine($"For Car: {Car.parkingFee(tcase)}");
                Console.WriteLine($"For Bus: {Bus.parkingFee(tcase)}");
                Console.WriteLine("");
            }
        }

    }
}
